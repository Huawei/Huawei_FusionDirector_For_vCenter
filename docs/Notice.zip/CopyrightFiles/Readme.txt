Spring Boot 2.1.3.RELEASE(05833FNL)Copyright信息为空，请手动添加. 
jackson-databind 2.9.3(05832RVS)Copyright信息为空，请手动添加. 
pydev for eclipse - pydev 6.5.0(05833DCF)Copyright信息为空，请手动添加. 
tomcat-embed-core 9.0.16(05833FUJ)Copyright信息为空，请手动添加. 
tomcat-embed-el 9.0.16(05833GAS)Copyright信息为空，请手动添加. 
tomcat-embed-websocket 9.0.16(05833GBM)Copyright信息为空，请手动添加. 
